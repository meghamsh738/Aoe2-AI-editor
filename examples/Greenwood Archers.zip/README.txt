AI Workshop experimental export

Native game test: NOT PERFORMED.
No game build has been certified.

Copy the matching Greenwood Archers.ai and Greenwood Archers.per files together into your DE AI directory (commonly resources/_common/ai inside the game installation). Back up any files with the same name before replacing them. Do not replace other bots. Restart the game if necessary. Select this bot and set its civilization to Britons.

Test profile: single-player 1v1 land map (e.g. Arabia), standard starting resources, Dark Age start, 200 population. The bot stays in Feudal Age. No naval play, walls, later ages, upgrades or custom reaction editor yet.

Record your game build, map seed, settings and any script errors. Check gathering, housing, 22-villager saving (or edited target), completed Feudal advancement, ranges, archer production and attacks. Repeat after losses. Static checks and policy tests cannot prove game compatibility or strength.

Project JSON is the editable source. Native code is generated output.
