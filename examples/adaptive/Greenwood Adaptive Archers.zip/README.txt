AI Workshop adaptive export

Native AoE II: DE status: UNVERIFIED. No game build has been certified.
Catalog: aoe2de-land-v1-reviewed-unverified (native-DE-validation-pending)
Command reference: https://airef.github.io/commands/commands-details.html
Pinned game data: https://github.com/SiegeEngineers/aoe2techtree/blob/b9d494df6921d4080df69b22f9dbb7a4d1dcd9f0/data/data.json

Use Greenwood Adaptive Archers.ai and Greenwood Adaptive Archers.per together. Select Britons on an Arabia-style 1v1 with standard resources, Dark Age start, and 200 population. The project JSON is the editable source. Record the game build, seed, script errors, replay, and observations with the included Windows test kit.
